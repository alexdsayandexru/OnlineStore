﻿namespace OnlineStore.Microservices.Product.Entities
{
    public class CategoryDTO : PersistentObjectDTO
    {
    }
}
