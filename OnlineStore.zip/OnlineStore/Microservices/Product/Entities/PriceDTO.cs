﻿namespace OnlineStore.Microservices.Product.Entities
{
    public class PriceDTO
    {
        public decimal Value { get; set; }
        public CurrencyDTO Currency { get; set; }
    }
}
