﻿namespace OnlineStore.Microservices.Product.Entities
{
    public enum MeasureDTO
    {
        Piece = 1, Kg = 2, Liter = 3
    }
}
