﻿namespace OnlineStore.Microservices.Product.Entities
{
    public enum CurrencyDTO
    {
        RUB = 1, USD = 2, EUR = 3
    }
}
