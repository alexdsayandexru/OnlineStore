﻿namespace OnlineStore.Microservices.Product.Entities
{
    public class QuantityDTO
    {
        public decimal Value { get; set; }
        public MeasureDTO Measure { get; set; }
    }
}
