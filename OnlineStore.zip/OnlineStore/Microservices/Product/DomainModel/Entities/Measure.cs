﻿namespace OnlineStore.Microservices.Product.DomainModel.Entities
{
    public enum Measure
    {
        Piece = 1, Kg = 2, Liter = 3
    }
}
