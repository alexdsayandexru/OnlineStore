﻿namespace OnlineStore.Microservices.Product.DomainModel.Entities
{
    public class Category : PersistentObject
    {
    }
}
