﻿namespace OnlineStore.Microservices.Product.DomainModel.Entities
{
    public enum Currency
    {
        RUB = 1, USD = 2, EUR = 3
    }
}
