﻿namespace OnlineStore.Microservices.Order
{
    public class OrderGateway : IOrderGateway
    {
    }
}
