﻿namespace OnlineStore.Microservices.Order
{
    public interface IOrderGateway
    {
    }
}
