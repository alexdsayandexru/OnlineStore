﻿namespace OnlineStore.Microservices.Payment
{
    public interface IPaymentGateway
    {
    }
}
