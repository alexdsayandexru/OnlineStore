﻿namespace OnlineStore.Microservices.Payment
{
    public class PaymentGateway : IPaymentGateway
    {
    }
}
