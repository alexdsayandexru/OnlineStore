﻿using System.Windows.Forms;

namespace OnlineStore
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
    }
}
